# Jadmin

By Jeff.#8017 for 5-Dev

- [Clique pour rejoindre le discord](https://discord.gg/5dev)

- [Vidéo présentation](https://youtu.be/U2GL1qgM478)


# Description

- Staff Mode
- Full Configurable
- Raccourcis de commandes
- Gestion des joueurs très complète
- Les fonctions indispensables à l'administration
- Tenue de modération que l'ont met/enlève à sa guise
- Des options pour l'utilitaire, les véhicules ou encore les armes
- un menu report complet et simple d'utilisation

# Notif

A mettre : `es_extended`/`server`/`classes`/`player.lua` :

```
function self.showNotification(msg)    
    TriggerClientEvent('esx:showNotification', self.source, msg)
end
```

# Installation


1. Installer la ressource et ajouter à votre répertoire de ressources
2. Ajouter `ensure Jadmin` dans votre `server.cfg`
3. Vérifier les ressources nécessaire au bon fonctionnement ci-dessous


# Requirements

- ESX
- [skinchanger](https://github.com/StockholmCityRP/skinchanger)
- [esx_skin](https://github.com/StockholmCityRP/esx_skin)
- [esx_jail](https://github.com/esx-community/esx_jail)
- [es_admin2](https://github.com/PrintedoX/es_admin2)
- [okokNotify](https://github.com/Filipe0071/okokNotify)

# Features

- Rework de la fonction Give Item de Enøs#0001
- Rework du menu report dans le rxwMenuAdmin de Rayan Waize#9995
- Utilisation du RageUI.Info de @Kalyptus

# Jadmin By Jeff.#8017 for 5-Dev (Copyright)



